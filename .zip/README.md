# Getting Started with Create React App
just unzip the current project folder and move to the folder and run command 
## yanr install

## Available Scripts

In the project directory, you can run:

### `yarn start`

Runs the app in the development mode.\
Open (http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

### `yarn test`

we are using msw liberay to mock data in test suite.jest react testing liberay,

