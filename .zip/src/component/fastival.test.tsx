import React from 'react';
import { screen, render } from '@testing-library/react';
import Fastivals from './fastival';

describe('fastival render Correctly',()=>{
    it('Component render Correctly ',()=>{
        render(<Fastivals/>)
        const textElement=screen.getByText(/Energy Australia/i)
        expect(textElement).toBeInTheDocument();
    });

    it('render the fastival list',async ()=>{
        render(<Fastivals/>)
        const fastivals= await screen.findAllByRole(/listitem/i);
        expect(fastivals).toHaveLength(1)
    })

})