
export const AppRoute={
        festivals_url: 'api/v1/festivals'
}