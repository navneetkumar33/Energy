export const fastivalsData = [{
    name: "LOL-palooza",
    bands: [{ name: 'Winter Primates', recordLabel: '' },
    { name: 'Frank Jupiter', recordLabel: 'Pacific Records' },
    { name: 'Jill Black', recordLabel: 'Fourth Woman Records' },
    { name: 'Werewolf Weekday', recordLabel: 'XS Recordings' },
    ]
},
{
    name: "LOL-palooza",
    bands: [{ name: 'Winter Primates', recordLabel: '' },
    { name: 'Frank Jupiter', recordLabel: 'Pacific Records' },
    { name: 'Jill Black', recordLabel: 'Fourth Woman Records' },
    { name: 'Werewolf Weekday', recordLabel: 'XS Recordings' },
    ]
}
]

