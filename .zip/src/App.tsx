import {useState, useEffect}from 'react';
import './App.css';
import Fastivals from './component/fastival';



function App() {
  
  return (
    <div className="App">
      <Fastivals />
    </div>
  );
}

export default App;
